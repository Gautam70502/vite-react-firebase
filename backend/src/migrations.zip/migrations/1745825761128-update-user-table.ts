import { MigrationInterface, QueryRunner } from 'typeorm';

export class UpdateUserTable1745825761128 implements MigrationInterface {
  name = 'UpdateUserTable1745825761128';

  public async up(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `CREATE TABLE "business_reference" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "first_name" citext NOT NULL, "last_name" citext NOT NULL, "business_name" citext NOT NULL, "contact_no" character varying(10), "email" character varying NOT NULL, "business_relationship" character varying, "user_id" uuid, CONSTRAINT "UQ_fa70c4c58987feacc2676247f7a" UNIQUE ("contact_no"), CONSTRAINT "UQ_decc84385d7f6538fa256001133" UNIQUE ("email"), CONSTRAINT "PK_f8b48c88ce7771f543819ee9b5d" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_fa70c4c58987feacc2676247f7" ON "business_reference" ("contact_no") `,
    );
    await queryRunner.query(
      `CREATE INDEX "IDX_decc84385d7f6538fa25600113" ON "business_reference" ("email") `,
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "IDX_28031cbd6ce4606bffd2731af1" ON "business_reference" ("first_name", "last_name", "email") `,
    );
    await queryRunner.query(
      `CREATE TABLE "city" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "created_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "updated_at" TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(), "deleted_at" TIMESTAMP WITH TIME ZONE, "created_by" uuid NOT NULL, "updated_by" uuid, "deleted_by" uuid, "name" character varying NOT NULL, "region_id" uuid NOT NULL, CONSTRAINT "UQ_f8c0858628830a35f19efdc0ecf" UNIQUE ("name"), CONSTRAINT "PK_b222f51ce26f7e5ca86944a6739" PRIMARY KEY ("id"))`,
    );
    await queryRunner.query(`ALTER TABLE "users" ADD "city" uuid`);
    await queryRunner.query(`ALTER TABLE "users" ADD "invited_by" uuid`);
    await queryRunner.query(`ALTER TABLE "users" ADD "heard_about_bni" text`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "bni_commitment_agreement" boolean DEFAULT true`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "substitute_commitment" boolean DEFAULT true`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "referral_commitment" boolean DEFAULT true`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "referral_ability_rating" numeric`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "previous_bni_membership" boolean DEFAULT false`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" ADD "other_networking_organizations" boolean DEFAULT false`,
    );
    await queryRunner.query(`ALTER TABLE "address" DROP COLUMN "state"`);
    await queryRunner.query(
      `ALTER TABLE "address" ADD "state" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "address" DROP COLUMN "country"`);
    await queryRunner.query(
      `ALTER TABLE "address" ADD "country" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "company" DROP COLUMN "name"`);
    await queryRunner.query(`ALTER TABLE "company" ADD "name" citext NOT NULL`);
    await queryRunner.query(`ALTER TABLE "notification" DROP COLUMN "title"`);
    await queryRunner.query(
      `ALTER TABLE "notification" ADD "title" citext NOT NULL`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_b6c400469d3f1b4bb9cf62e10f"`,
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "first_name"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "first_name" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "last_name"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "last_name" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "meeting" DROP COLUMN "name"`);
    await queryRunner.query(`ALTER TABLE "meeting" ADD "name" citext NOT NULL`);
    await queryRunner.query(`ALTER TABLE "meeting" DROP COLUMN "location"`);
    await queryRunner.query(
      `ALTER TABLE "meeting" ADD "location" citext NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "chapter" DROP CONSTRAINT "UQ_02782d7f837ca2989ce87f03ca0"`,
    );
    await queryRunner.query(`ALTER TABLE "chapter" DROP COLUMN "name"`);
    await queryRunner.query(
      `ALTER TABLE "chapter" ADD "name" character varying NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "chapter" ADD CONSTRAINT "UQ_02782d7f837ca2989ce87f03ca0" UNIQUE ("name")`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "title"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "title" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "first_name"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "first_name" citext NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "last_name"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "last_name" citext NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD CONSTRAINT "UQ_e1b0fa4a31c6e2b15f18f9db59a" UNIQUE ("email")`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "company_name"`);
    await queryRunner.query(`ALTER TABLE "visitor" ADD "company_name" citext`);
    await queryRunner.query(
      `CREATE UNIQUE INDEX "IDX_b6c400469d3f1b4bb9cf62e10f" ON "users" ("first_name", "last_name", "email") `,
    );
    await queryRunner.query(
      `ALTER TABLE "business_reference" ADD CONSTRAINT "FK_b39e38f237a8d20a2b8ec9b4717" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
    await queryRunner.query(
      `ALTER TABLE "city" ADD CONSTRAINT "FK_0b663dca66456beb75ec93de9fc" FOREIGN KEY ("region_id") REFERENCES "region"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`,
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(
      `ALTER TABLE "city" DROP CONSTRAINT "FK_0b663dca66456beb75ec93de9fc"`,
    );
    await queryRunner.query(
      `ALTER TABLE "business_reference" DROP CONSTRAINT "FK_b39e38f237a8d20a2b8ec9b4717"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_b6c400469d3f1b4bb9cf62e10f"`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "company_name"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "company_name" character varying(50)`,
    );
    await queryRunner.query(
      `ALTER TABLE "visitor" DROP CONSTRAINT "UQ_e1b0fa4a31c6e2b15f18f9db59a"`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "last_name"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "last_name" character varying(50) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "first_name"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "first_name" character varying(50) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "visitor" DROP COLUMN "title"`);
    await queryRunner.query(
      `ALTER TABLE "visitor" ADD "title" character varying(50) NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "chapter" DROP CONSTRAINT "UQ_02782d7f837ca2989ce87f03ca0"`,
    );
    await queryRunner.query(`ALTER TABLE "chapter" DROP COLUMN "name"`);
    await queryRunner.query(
      `ALTER TABLE "chapter" ADD "name" character varying(50) NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "chapter" ADD CONSTRAINT "UQ_02782d7f837ca2989ce87f03ca0" UNIQUE ("name")`,
    );
    await queryRunner.query(`ALTER TABLE "meeting" DROP COLUMN "location"`);
    await queryRunner.query(
      `ALTER TABLE "meeting" ADD "location" character varying NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "meeting" DROP COLUMN "name"`);
    await queryRunner.query(
      `ALTER TABLE "meeting" ADD "name" character varying(50) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "last_name"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "last_name" character varying(20) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "first_name"`);
    await queryRunner.query(
      `ALTER TABLE "users" ADD "first_name" character varying(20) NOT NULL`,
    );
    await queryRunner.query(
      `CREATE UNIQUE INDEX "IDX_b6c400469d3f1b4bb9cf62e10f" ON "users" ("first_name", "last_name", "email") `,
    );
    await queryRunner.query(`ALTER TABLE "notification" DROP COLUMN "title"`);
    await queryRunner.query(
      `ALTER TABLE "notification" ADD "title" character varying(50) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "company" DROP COLUMN "name"`);
    await queryRunner.query(
      `ALTER TABLE "company" ADD "name" character varying NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "address" DROP COLUMN "country"`);
    await queryRunner.query(
      `ALTER TABLE "address" ADD "country" character varying(50) NOT NULL`,
    );
    await queryRunner.query(`ALTER TABLE "address" DROP COLUMN "state"`);
    await queryRunner.query(
      `ALTER TABLE "address" ADD "state" character varying(50) NOT NULL`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "other_networking_organizations"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "previous_bni_membership"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "referral_ability_rating"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "referral_commitment"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "substitute_commitment"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "bni_commitment_agreement"`,
    );
    await queryRunner.query(
      `ALTER TABLE "users" DROP COLUMN "heard_about_bni"`,
    );
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "invited_by"`);
    await queryRunner.query(`ALTER TABLE "users" DROP COLUMN "city"`);
    await queryRunner.query(`DROP TABLE "city"`);
    await queryRunner.query(
      `DROP INDEX "public"."IDX_28031cbd6ce4606bffd2731af1"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_decc84385d7f6538fa25600113"`,
    );
    await queryRunner.query(
      `DROP INDEX "public"."IDX_fa70c4c58987feacc2676247f7"`,
    );
    await queryRunner.query(`DROP TABLE "business_reference"`);
  }
}
